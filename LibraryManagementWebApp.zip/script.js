const $=id=>document.getElementById(id);
const today=()=>new Date().toISOString().slice(0,10);
const addDays=(date,n)=>{let d=new Date(date);d.setDate(d.getDate()+n);return d.toISOString().slice(0,10)};
let role="student", currentUser="", books=[
{id:1,title:"Java Programming",author:"Herbert Schildt",category:"Programming",qty:5},
{id:2,title:"Database System Concepts",author:"Silberschatz",category:"Database",qty:3},
{id:3,title:"Operating System Concepts",author:"Abraham Silberschatz",category:"Computer Science",qty:4},
{id:4,title:"Clean Code",author:"Robert C. Martin",category:"Programming",qty:2}
];
let loans=[], payments=[];

document.querySelectorAll(".role-btn").forEach(b=>b.onclick=()=>{
 role=b.dataset.role;
 document.querySelectorAll(".role-btn").forEach(x=>x.classList.remove("active"));
 b.classList.add("active");
});
$("loginForm").onsubmit=e=>{
 e.preventDefault();
 const u=$("username").value.trim(),p=$("password").value;
 const valid=(role==="student"&&u==="student"&&p==="1234")||(role==="library"&&u==="librarian"&&p==="1234");
 if(!valid){$("loginMessage").innerHTML='<p style="color:#c62828">Invalid demo login. Use student/1234 or librarian/1234.</p>';return}
 currentUser=u;$("loginPage").classList.add("hidden");$("dashboardPage").classList.remove("hidden");
 document.querySelectorAll(".student-only,.student-only-section").forEach(x=>x.classList.toggle("hidden",role!=="student"));
 document.querySelectorAll(".library-only,.library-only-section").forEach(x=>x.classList.toggle("hidden",role!=="library"));
 $("welcomeUser").textContent=`${role==="student"?"Student":"Librarian"}: ${u}`;
 showSection("overview");render();
};
$("logoutBtn").onclick=()=>location.reload();
document.querySelectorAll(".nav-btn").forEach(b=>b.onclick=()=>showSection(b.dataset.section));
function showSection(id){
 document.querySelectorAll(".page-section").forEach(s=>s.classList.add("hidden"));
 $(id).classList.remove("hidden");
 document.querySelectorAll(".nav-btn").forEach(b=>b.classList.toggle("active",b.dataset.section===id));
 render();
}
function fineFor(l){let due=new Date(l.due),now=new Date();let days=Math.max(0,Math.floor((now-due)/86400000));return days*5}
function render(){
 $("statBooks").textContent=books.reduce((a,b)=>a+b.qty,0);
 $("statIssued").textContent=loans.filter(l=>!l.returned).length;
 const fines=loans.filter(l=>!l.returned).reduce((a,l)=>a+fineFor(l),0);
 $("statDue").textContent=loans.filter(l=>!l.returned&&new Date(l.due)<new Date()).length;
 $("statFine").textContent=`₹${fines}`;
 renderBooks();renderMyBooks();renderManage();renderPayments();
}
function renderBooks(){
 const q=($("bookSearch")?.value||"").toLowerCase();
 $("bookGrid").innerHTML=books.filter(b=>(b.title+b.author+b.category).toLowerCase().includes(q)).map(b=>`
 <div class="book"><div class="cover">📕</div><span class="badge">${b.category}</span>
 <h3>${b.title}</h3><p class="muted">${b.author}</p><p>Available: <b>${b.qty}</b></p>
 ${role==="student"?`<button class="primary" ${b.qty<1?"disabled":""} onclick="issue(${b.id})">${b.qty?"Issue Book":"Unavailable"}</button>`:""}
 </div>`).join("");
}
function issue(id){
 let b=books.find(x=>x.id===id);if(!b||b.qty<1)return;
 b.qty--;loans.push({id:Date.now(),bookId:id,issue:today(),due:addDays(today(),14),returned:false});
 toast(`${b.title} issued. Due on ${addDays(today(),14)}.`);
 render();
}
function renderMyBooks(){
 if(role!=="student")return;
 $("myBooksTable").innerHTML=loans.map(l=>{
 let b=books.find(x=>x.id===l.bookId),fine=fineFor(l),status=l.returned?"Returned":fine?"Overdue":"Active";
 return `<tr><td>${b?.title||"Book"}</td><td>${l.issue}</td><td>${l.due}</td><td>${status}</td><td>₹${fine}</td>
 <td>${!l.returned?`<button class="primary" onclick="returnBook(${l.id})">Return</button>`:"—"}</td></tr>`}).join("")||`<tr><td colspan="6">No books issued.</td></tr>`;
}
function returnBook(id){
 let l=loans.find(x=>x.id===id);if(!l)return;l.returned=true;
 let b=books.find(x=>x.id===l.bookId);if(b)b.qty++;
 let fine=fineFor(l);if(fine)payments.push({date:today(),desc:`Late fine - ${b?.title||"Book"}`,amount:fine,status:"Pending"});
 toast("Book returned successfully.");render();
}
$("bookSearch").oninput=renderBooks;
$("bookForm").onsubmit=e=>{
 e.preventDefault();books.push({id:Date.now(),title:$("bookTitle").value,author:$("bookAuthor").value,category:$("bookCategory").value,qty:+$("bookQty").value});
 e.target.reset();$("bookQty").value=1;toast("Book added.");render();
};
function renderManage(){
 if(role!=="library")return;
 $("manageTable").innerHTML=books.map(b=>`<tr><td>${b.id}</td><td>${b.title}</td><td>${b.author}</td><td>${b.category}</td><td>${b.qty}</td><td><button class="logout" onclick="removeBook(${b.id})">Delete</button></td></tr>`).join("");
}
function removeBook(id){if(loans.some(l=>l.bookId===id&&!l.returned)){toast("Cannot delete an issued book.");return}books=books.filter(b=>b.id!==id);toast("Book removed.");render()}
function renderPayments(){
 let pending=payments.filter(p=>p.status==="Pending").reduce((a,p)=>a+p.amount,0);
 $("pendingAmount").textContent=`₹${pending}`;$("payBtn").disabled=pending===0;
 $("paymentTable").innerHTML=payments.map(p=>`<tr><td>${p.date}</td><td>${p.desc}</td><td>₹${p.amount}</td><td>${p.status}</td></tr>`).join("")||`<tr><td colspan="4">No payment records.</td></tr>`;
}
$("payBtn").onclick=()=>{payments.forEach(p=>{if(p.status==="Pending")p.status="Paid"});$("paymentMessage").textContent="Payment recorded successfully (demo mode).";toast("Payment successful.");renderPayments()};
function toast(msg){$("toast").textContent=msg;$("toast").classList.add("show");setTimeout(()=>$("toast").classList.remove("show"),2500)}
render();
